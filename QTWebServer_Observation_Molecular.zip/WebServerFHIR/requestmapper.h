#ifndef REQUESTMAPPER_H
#define REQUESTMAPPER_H
#include "httprequesthandler.h"
#include "datatemplatecontroller.h"
#include "observation.h"
#include "molecularsequence.h"
#include "net.h"

using namespace stefanfrings;

class RequestMapper : public HttpRequestHandler {
    Q_OBJECT
public:
    RequestMapper(QObject* parent=0);
    void service(HttpRequest& request, HttpResponse& response);
private :
    DataTemplateController dataTemplateController;
    QString CSV_PATH;
    Observation Observe;
    molecularsequence Molecular;
    QString BundlePath_Obs,BundlePath_Mol;
    QJsonObject Bundle;
    Net handler;
    int limit;
};
#endif // REQUESTMAPPER_H
