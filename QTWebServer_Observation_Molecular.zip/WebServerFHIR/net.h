#ifndef NET_H
#define NET_H


#include <QObject>

#include <QtCore>
#include <QNetworkAccessManager>
#include <QNetworkReply>

class Net : public QObject
{
Q_OBJECT
  QNetworkAccessManager manager;
/*private slots:
  void requestFinished(QNetworkReply *);*/
public:
  Net();
  void PostData(QString url,QString Value);
};

#endif // NET_H
