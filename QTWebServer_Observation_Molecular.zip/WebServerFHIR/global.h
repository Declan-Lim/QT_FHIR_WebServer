#ifndef GLOBAL_H
#define GLOBAL_H

#include "staticfilecontroller.h"
#include "templatecache.h"
//#include "httpsessionstore.h"

using namespace stefanfrings;

extern StaticFileController* staticFileController;
extern TemplateCache* templateCache;
//extern HttpSessionStore* sessionStore;

#endif // GLOBAL_H
