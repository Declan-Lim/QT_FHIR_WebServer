#include "observation.h"

Observation::Observation()
{
    current=0;
    RowCount=0;
}

void Observation::ReadCSV(QString Path){
    QByteArray strArray;
    QStringList splitStr;
    QString G_Column[4000],J_Column[4000];
    QFile myfile(Path);
    if (myfile.open(QIODevice::ReadOnly)) {
            myfile.readLine();//read title 1st
            while (!myfile.atEnd()) { // can use third parameter on getline (getline(myfile,line,',')) to split data
                strArray = myfile.readLine();
                splitStr = QString(strArray).split(",");
                 G_Column[RowCount] = splitStr[6];
                 J_Column[RowCount] = splitStr[9];
                 if (J_Column[RowCount][0] == '"')  J_Column[RowCount].remove('"');
                  GCol.push_back(G_Column[RowCount]);
                  JCol.push_back(J_Column[RowCount]);
                  RowCount++;
              }
            myfile.close();
            if (GCol.size() != 0 && JCol.size()!=0) {
                //printOut(GCol, JCol);
            }
    }
    else {
        qDebug()<<"Reading CSV error";
    }
}

void Observation::ReadExampleJson(QString Path){
    QString val;
    QFile file(Path);
    if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
        val = file.readAll();
        file.close();
        QJsonDocument doc = QJsonDocument::fromJson(val.toUtf8());
        example  = doc.object();
    }
    else{
        qDebug()<<"Reading template error";
    }
    //qDebug().noquote() << example_str;
}

void Observation::ReadLibrary(QString Path){
    QString val;
    QFile file(Path);
    if(file.open(QIODevice::ReadOnly|QIODevice::Text)){
        val = file.readAll();
        file.close();
        QJsonDocument doc = QJsonDocument::fromJson(val.toUtf8());
        library = doc.object();
        doc = QJsonDocument::fromJson(JsonString(library["response"].toObject()).toUtf8());
        library = doc.object();
        libArray = library["docs"].toArray();
    }
    else{
        qDebug()<<"Reading library error";
    }
    //qDebug().noquote() << libArray;
}

QString Observation::JsonString(QJsonObject ob){
    QJsonDocument doc(ob);
    QByteArray arr = doc.toJson();
    return QString(arr);
}

void Observation :: Initialize(QString SpecimenID ,QString Analysis,QString Genomic,QString Display){
    QJsonObject specimen = example["specimen"].toObject();
    specimen["reference"]= "Specimen/"+SpecimenID;
    example["specimen"]=specimen;
    QJsonObject analyse = example["method"].toObject();
    QJsonObject valueCode = analyse["valueCodeableConcept"].toObject();
    QJsonArray coding = valueCode["coding"].toArray();
    QJsonObject cod1 = coding[0].toObject();
    cod1["code"]=Analysis;
    coding[0] = cod1;
    valueCode["coding"]= coding;
    analyse["valueCodeableConcept"] = valueCode;
    example["method"] = analyse;
    QJsonArray comp = example["component"].toArray();
    for(int i=0;i<comp.count();i++){
        QJsonObject temp = comp[i].toObject();
        temp = temp["code"].toObject();
        QJsonArray tempArr = temp["coding"].toArray();
        temp = tempArr[0].toObject();
        if(temp["code"]=="48002-0"){
            QJsonObject obj = comp[i].toObject();
            QJsonObject vall = obj["valueCodeableConcept"].toObject();
            QJsonArray coding = vall["coding"].toArray();
            for(int k=0;k<coding.count();k++){
                QJsonObject ob = coding[k].toObject();
                if(ob.contains("code")){
                    ob["code"]=Genomic;
                    ob["display"] = Display;
                    coding[k]= ob;
                    vall["coding"]=coding;
                    obj["valueCodeableConcept"] = vall;
                    comp[i]=obj;
                }
            }
            example["component"]=comp;
        }
    }


    example_str = JsonString(example);
    //qDebug().noquote() << example_str;
}

QJsonObject Observation::FormJson(QString Gene, QString Changed) {
    QString ID,editedText;
    //Gene match with symbol --> look for hgnc_id
    ID = FindID(Gene);
    if(ID == "")ID = FindPrevID(Gene);
    //cant find SLC35E2 -- is SLC35E2A??
    QJsonDocument doc = QJsonDocument::fromJson(example_str.toUtf8());
    QJsonObject root = doc.object();
    QJsonArray comp = root["component"].toArray();
    for(int i=0;i<comp.count();i++){
        QJsonObject temp = comp[i].toObject();
        temp = temp["code"].toObject();
        QJsonArray tempArr = temp["coding"].toArray();
        temp = tempArr[0].toObject();
       if(temp["code"]=="48018-6"){
           QJsonObject obj = comp[i].toObject();
           QJsonObject vall = obj["valueCodeableConcept"].toObject();
           QJsonArray coding = vall["coding"].toArray();
           for(int k=0;k<coding.count();k++){
               QJsonObject ob = coding[k].toObject();
               if(ob.contains("code")){
                   ob["code"]=ID;
                   ob["display"] = Gene;
                   coding[k]= ob;
                   vall["coding"]=coding;
                   obj["valueCodeableConcept"] = vall;
                   comp[i]=obj;
               }
           }
       }
       else if(temp["code"]=="48005-3"){
            if(Changed!="UNKNOWN") editedText = tokenize(Changed);
            else editedText = Changed;
            QJsonObject obj2 = comp[i].toObject();
            QJsonObject vall2 = obj2["valueCodeableConcept"].toObject();
            QJsonArray coding2 = vall2["coding"].toArray();
            for(int k=0;k<coding2.count();k++){
                QJsonObject ob2 = coding2[k].toObject();
                if(ob2.contains("code")){
                    ob2["code"]=editedText;
                    coding2[k]= ob2;
                    vall2["coding"]=coding2;
                    obj2["valueCodeableConcept"] = vall2;
                    comp[i]=obj2;
                }
            }
       }
    }
    root["component"] = comp;
    return root;
    qDebug().noquote() << JsonString(root);
}

QString Observation::FindID(QString Gene){
    for(int i=0;i<libArray.count();i++){
        QJsonObject obj = libArray[i].toObject();
        if(obj["symbol"].toString() == Gene){
            return obj["hgnc_id"].toString();
        }
    }
    return "";
}

QString Observation::FindPrevID(QString Gene){
    for(int i=0;i<libArray.count();i++){
        QJsonObject obj = libArray[i].toObject();
        if(obj["prev_symbol"].toString() == Gene){
            return obj["hgnc_id"].toString();
        }
    }
    return "";
}

QString Observation::tokenize(QString s) {
    QString result;
    QStringList stringList = s.split(":"),temp,Options;
    Options<<"A"<<"R"<<"N"<<"D"<<"C"<<"E"<<"Q"<<"H"<<"I"<<"L"<<"K"<<"M"<<"F"<<"P"<<"S"<<"T"<<"W"<<"Y"<<"V";
    for(int i=0;i<stringList.count();i++){
        if(i==1){
            result=stringList[i]+":";
        }
        else if(i==4){
            temp=stringList[i].split(".");
            QString Parse = temp[1];
            for(int k=0;k<Parse.count();k++){
                QString n = QString(Parse[k]);
                switch (Options.indexOf(n)){
                            case 0:
                                Parse.replace(k, 1, "Ala");
                                break;
                            case 1:
                                Parse.replace(k, 1, "Arg");
                                break;
                            case 2:
                                Parse.replace(k, 1, "Asn");
                                break;
                            case 3:
                                Parse.replace(k, 1, "Asp");
                                break;
                            case 4:
                                Parse.replace(k, 1, "Cys");
                                break;
                            case 5:
                                Parse.replace(k, 1, "Glu");
                                break;
                            case 6:
                                Parse.replace(k, 1, "Gln");
                                break;
                            case 7:
                                Parse.replace(k, 1, "His");
                                break;
                            case 8:
                                Parse.replace(k, 1, "Ile");
                                break;
                            case 9:
                                Parse.replace(k, 1, "Leu");
                                break;
                            case 10:
                                Parse.replace(k, 1, "Lys");
                                break;
                            case 11:
                                Parse.replace(k, 1, "Met");
                                break;
                            case 12:
                                Parse.replace(k, 1, "Phe");
                                break;
                            case 13:
                                Parse.replace(k, 1, "Pro");
                                break;
                            case 14:
                                Parse.replace(k, 1, "Ser");
                                break;
                            case 15:
                                Parse.replace(k, 1, "Thr");
                                break;
                            case 16:
                                Parse.replace(k, 1, "Trp");
                                break;
                            case 17:
                                Parse.replace(k, 1, "Tyr");
                                break;
                            case 18:
                                Parse.replace(k, 1, "Val");
                                break;
                            }
            }
            result+=temp[0]+"."+Parse;
        }
    }
    return result;
}
