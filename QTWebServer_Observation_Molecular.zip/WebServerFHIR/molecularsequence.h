#ifndef MOLECULARSEQUENCE_H
#define MOLECULARSEQUENCE_H

#include <QByteArray>
#include <QString>
#include <QMap>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QJsonDocument>
#include <QDebug>

struct DataSlot{
    QString Chrom,Start,End,Ref,Alt;
};typedef struct DataSlot DataSlot;

class molecularsequence
{
public:
    molecularsequence();
    void ReadExampleJson(QString Path);
    void ReadCSV(QString Path);
    QString JsonString(QJsonObject ob);
    void Initialize(QString SpecimenID,QString Sequence,QString Genome,QString WindowRange,QString Coordinate,QString Strand);
    QJsonObject FormJson(DataSlot C,int index);
    QList<DataSlot>dataVal;
    QJsonObject example;
    QString example_str;
    int Range,Current;
};

#endif // MOLECULARSEQUENCE_H
