var annotated_dup =
[
    [ "stefanfrings", null, [
      [ "Template", "classstefanfrings_1_1Template.html", "classstefanfrings_1_1Template" ],
      [ "TemplateCache", "classstefanfrings_1_1TemplateCache.html", "classstefanfrings_1_1TemplateCache" ],
      [ "TemplateLoader", "classstefanfrings_1_1TemplateLoader.html", "classstefanfrings_1_1TemplateLoader" ],
      [ "DualFileLogger", "classstefanfrings_1_1DualFileLogger.html", "classstefanfrings_1_1DualFileLogger" ],
      [ "FileLogger", "classstefanfrings_1_1FileLogger.html", "classstefanfrings_1_1FileLogger" ],
      [ "Logger", "classstefanfrings_1_1Logger.html", "classstefanfrings_1_1Logger" ],
      [ "LogMessage", "classstefanfrings_1_1LogMessage.html", "classstefanfrings_1_1LogMessage" ],
      [ "HttpConnectionHandler", "classstefanfrings_1_1HttpConnectionHandler.html", "classstefanfrings_1_1HttpConnectionHandler" ],
      [ "HttpConnectionHandlerPool", "classstefanfrings_1_1HttpConnectionHandlerPool.html", "classstefanfrings_1_1HttpConnectionHandlerPool" ],
      [ "HttpCookie", "classstefanfrings_1_1HttpCookie.html", "classstefanfrings_1_1HttpCookie" ],
      [ "HttpListener", "classstefanfrings_1_1HttpListener.html", "classstefanfrings_1_1HttpListener" ],
      [ "HttpRequest", "classstefanfrings_1_1HttpRequest.html", "classstefanfrings_1_1HttpRequest" ],
      [ "HttpRequestHandler", "classstefanfrings_1_1HttpRequestHandler.html", "classstefanfrings_1_1HttpRequestHandler" ],
      [ "HttpResponse", "classstefanfrings_1_1HttpResponse.html", "classstefanfrings_1_1HttpResponse" ],
      [ "HttpSession", "classstefanfrings_1_1HttpSession.html", "classstefanfrings_1_1HttpSession" ],
      [ "HttpSessionStore", "classstefanfrings_1_1HttpSessionStore.html", "classstefanfrings_1_1HttpSessionStore" ],
      [ "StaticFileController", "classstefanfrings_1_1StaticFileController.html", "classstefanfrings_1_1StaticFileController" ]
    ] ]
];