var classQtServiceController =
[
    [ "StartupType", "classQtServiceController.html#a946ac2b079d9760503da923c2eaf0aac", [
      [ "AutoStartup", "classQtServiceController.html#a946ac2b079d9760503da923c2eaf0aaca04b30fbcd3059d3186fd85cd7a57e01f", null ],
      [ "ManualStartup", "classQtServiceController.html#a946ac2b079d9760503da923c2eaf0aacaf7bdf7d6bc457c96fb92938c758a87f6", null ]
    ] ],
    [ "QtServiceController", "classQtServiceController.html#ab5c5bb7d168d2e59f0784ded380d7adf", null ],
    [ "~QtServiceController", "classQtServiceController.html#a3288eead2b9862c3a70e7decbaebc908", null ],
    [ "isInstalled", "classQtServiceController.html#a7e36fb18a273118709faf22f732feac4", null ],
    [ "isRunning", "classQtServiceController.html#a4a11b35468848388174a36af66f25fc3", null ],
    [ "pause", "classQtServiceController.html#aeee2fcc9469f77c7ed8a7955c4fa3a07", null ],
    [ "resume", "classQtServiceController.html#a2d71eab6146427fc7b431386bf72eaec", null ],
    [ "sendCommand", "classQtServiceController.html#a1428c7d51403416bc7663ae37c446cfc", null ],
    [ "serviceDescription", "classQtServiceController.html#a503c0fadf098b4c5bbccbb2a57f911e2", null ],
    [ "serviceFilePath", "classQtServiceController.html#a5ab709fdeb3ab526c92ccbbe1b2706c6", null ],
    [ "serviceName", "classQtServiceController.html#a3df972ecd01a00fff5cda316ae35cbea", null ],
    [ "start", "classQtServiceController.html#a5e9d6da5081d70f31611456d0ef0687e", null ],
    [ "start", "classQtServiceController.html#a70f274d3f4f5a5fea60b8fd7331b31fb", null ],
    [ "startupType", "classQtServiceController.html#acfd3b5cb23c17bf415f1d606b8461109", null ],
    [ "stop", "classQtServiceController.html#ad06afa647666769e309474b18bf7cf90", null ],
    [ "uninstall", "classQtServiceController.html#a25cd2f1f6868ece5de77976eb55cb74c", null ]
];