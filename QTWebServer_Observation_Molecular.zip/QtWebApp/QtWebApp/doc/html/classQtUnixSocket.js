var classQtUnixSocket =
[
    [ "QtUnixSocket", "classQtUnixSocket.html#a5c8729be0bb51069bc5011c131a3c396", null ],
    [ "connectTo", "classQtUnixSocket.html#a412e4407c955f2cfceabdae69f1626ff", null ]
];