var httpconnectionhandler_8h =
[
    [ "HttpConnectionHandler", "classstefanfrings_1_1HttpConnectionHandler.html", "classstefanfrings_1_1HttpConnectionHandler" ],
    [ "tSocketDescriptor", "httpconnectionhandler_8h.html#aac9d80ca2f2f3e2c74506d3b207b02d6", null ]
];